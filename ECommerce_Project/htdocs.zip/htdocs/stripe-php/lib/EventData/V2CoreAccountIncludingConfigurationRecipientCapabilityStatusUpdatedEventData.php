<?php

// File generated from our OpenAPI spec

namespace Stripe\EventData;

/**
 * @property string $updated_capability Open Enum. The capability which had its status updated.
 */
class V2CoreAccountIncludingConfigurationRecipientCapabilityStatusUpdatedEventData extends \Stripe\StripeObject {}
