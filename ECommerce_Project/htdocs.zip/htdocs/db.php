<?php
    $hostname="sql300.infinityfree.com";
	$username="if0_41027982";
	$password="Khandal12345";
	$db_name="if0_41027982_ecoproject";

	$conn=mysqli_connect($hostname, $username, $password, $db_name);
?>