<?php
// Secure Configuration File
define('STRIPE_SECRET_KEY', 'sk_test_51SwZrZ****<Enter Your Stripe API Key Here>');

// Database Credentials (Optional but recommended to move here)
define('DB_HOST', '<DB HOST ADDRESS>');
define('DB_USER', '<DB USERNAME>');
define('DB_PASS', '<DB USER PASSWORD>');
define('DB_NAME', '<DB NAME>');

define('STRIPE_WEBHOOK_SECRET', 'whsec_ciTR****<Enter Your Stripe Webhook Key>');
?>

