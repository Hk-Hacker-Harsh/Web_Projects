<?php
// Secure Configuration File
define('STRIPE_SECRET_KEY', 'sk_test_51SwZrZR8dFqYSCBsXd*****EnterYourAPIHere');

// Database Credentials (Optional but recommended to move here)
define('DB_HOST', '<Enter DB HOST Here>');
define('DB_USER', '<Enter DB User>');
define('DB_PASS', '<Enter DB Password>');
define('DB_NAME', '<Enter DB NAME>');

define('STRIPE_WEBHOOK_SECRET', 'whsec_ci****EnterYourWebhookKey');
?>

