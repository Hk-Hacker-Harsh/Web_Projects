<?php

// File generated from our OpenAPI spec

namespace Stripe\EventData;

/**
 * @property string $account_id The ID of the v2 account.
 */
class V2CoreAccountPersonCreatedEventData extends \Stripe\StripeObject {}
