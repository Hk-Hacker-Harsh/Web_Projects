<!DOCTYPE html>
<html>
<head><title>Something Went Wrong</title></head>
<body style="text-align:center; padding:50px; font-family:sans-serif;">
    <h1>Oops! Something went wrong.</h1>
    <p>We are experiencing a technical issue. Our team has been notified.</p>
    <a href="index.php">Return to Home</a>
</body>
</html>